# alarmClock
Assignment 1, Object Oriented JavaScript SD-120 MITT
